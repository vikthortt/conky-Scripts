#!/bin/sh

conky -b -c /home/vikthor/.conky/conky_silicaCalend &
conky -b -c /home/vikthor/.conky/SAO_theme/conky_saoClock &
conky -b -c /home/vikthor/.conky/SAO_theme/conky_hpbar &
